<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="dead-tree-2-1.png" tilewidth="16" tileheight="16" tilecount="16" columns="4">
 <image source="dead-tree-2-1.png.png" width="64" height="64"/>
</tileset>
